const projectName = 'survey-form';
localStorage.setItem('example_project', 'Survey Form');